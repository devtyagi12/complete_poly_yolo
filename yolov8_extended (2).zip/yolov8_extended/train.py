"""
Training script for YOLOv8-Extended.

Single-GPU
──────────
  python train.py --poly_dataset_root data/polygon --num_classes 10

Multi-GPU (DDP via torchrun)
─────────────────────────────
  # 2 GPUs on one machine
  torchrun --nproc_per_node 2 train.py \\
      --poly_dataset_root data/polygon --num_classes 10

  # 2 machines × 4 GPUs each
  torchrun --nnodes 2 --nproc_per_node 4 \\
           --node_rank 0 --master_addr HOST --master_port 29500 \\
      train.py --poly_dataset_root data/polygon --num_classes 10

Other examples
──────────────
  python train.py --cfg configs/my_exp.yaml --epochs 100 --batch_size 8
  python train.py --resume runs/train/exp1/last.pt
  python train.py --no_amp   # disable AMP for unsupported GPUs
"""
from __future__ import annotations

import copy
import math
import os
import time
from pathlib import Path
from typing import List, Optional, Tuple

import torch
import torch.distributed as dist
import torch.multiprocessing as mp
import torch.optim as optim
from torch.amp import GradScaler, autocast
from torch.nn.parallel import DistributedDataParallel as DDP
from torch.utils.data.distributed import DistributedSampler

from configs.config import Config, load_config, save_config
from data.dataset import build_dataloader
from loss.loss import YOLOv8ExtendedLoss
from models.model import YOLOv8Extended
from postprocess.decode import PostProcessor
from utils.logger import Logger
from utils.metrics import BBoxF1Metric
from utils.visualiser import Visualiser


# ─────────────────────────────────────────────────────────────────────────────
# DDP helpers
# ─────────────────────────────────────────────────────────────────────────────

def _ddp_setup(rank: int, world_size: int, backend: str = "nccl") -> None:
    """Initialise the default process group for DDP."""
    dist.init_process_group(
        backend    = backend,
        rank       = rank,
        world_size = world_size,
    )
    torch.cuda.set_device(rank)


def _ddp_teardown() -> None:
    dist.destroy_process_group()


def _is_ddp() -> bool:
    return dist.is_available() and dist.is_initialized()


def _rank() -> int:
    return dist.get_rank() if _is_ddp() else 0


def _world_size() -> int:
    return dist.get_world_size() if _is_ddp() else 1


def _is_main() -> bool:
    """True on the rank-0 process (or single-GPU)."""
    return _rank() == 0


def _barrier() -> None:
    if _is_ddp():
        dist.barrier()


def _reduce_mean(tensor: torch.Tensor) -> torch.Tensor:
    """All-reduce a scalar tensor and divide by world size."""
    if not _is_ddp():
        return tensor
    dist.all_reduce(tensor, op=dist.ReduceOp.SUM)
    return tensor / _world_size()


# ─────────────────────────────────────────────────────────────────────────────
# Save-dir
# ─────────────────────────────────────────────────────────────────────────────

def _resolve_save_dir(base: str, resume_path: Optional[str]) -> Path:
    """
    Return the experiment directory.
    If resuming, returns the checkpoint's parent directory.
    Otherwise finds the next free expN sub-directory.
    Only rank-0 creates the directory; all ranks wait at the barrier.
    """
    if resume_path:
        return Path(resume_path).parent

    if _is_main():
        base_path = Path(base)
        for i in range(1, 10_000):
            candidate = base_path / f"exp{i}"
            if not candidate.exists():
                candidate.mkdir(parents=True)
                break
        result = candidate
    else:
        result = None   # filled in after broadcast

    # broadcast save_dir from rank-0 to all ranks
    if _is_ddp():
        objects = [str(result) if _is_main() else None]
        dist.broadcast_object_list(objects, src=0)
        result = Path(objects[0])

    _barrier()
    return result


# ─────────────────────────────────────────────────────────────────────────────
# LR schedule
# ─────────────────────────────────────────────────────────────────────────────

def _cosine_lr(optimizer, epoch, total_epochs, warmup_epochs, lr0, lrf):
    if epoch < warmup_epochs:
        lr = lr0 * (epoch + 1) / max(warmup_epochs, 1)
    else:
        t  = (epoch - warmup_epochs) / max(total_epochs - warmup_epochs, 1)
        lr = lrf + 0.5 * (lr0 - lrf) * (1 + math.cos(math.pi * t))
    for pg in optimizer.param_groups:
        pg["lr"] = lr
    return lr


# ─────────────────────────────────────────────────────────────────────────────
# EMA  (rank-0 only)
# ─────────────────────────────────────────────────────────────────────────────

class ModelEMA:
    def __init__(self, model: torch.nn.Module, decay: float = 0.9999):
        # EMA tracks the raw (non-DDP) module
        raw = model.module if isinstance(model, DDP) else model
        self.ema     = copy.deepcopy(raw)
        self.decay   = decay
        self.updates = 0

    @torch.no_grad()
    def update(self, model: torch.nn.Module):
        self.updates += 1
        d   = self.decay * (1 - math.exp(-self.updates / 2000))
        # always read from the underlying module even if DDP-wrapped
        raw = model.module if isinstance(model, DDP) else model
        msd = raw.state_dict()
        for k, v in self.ema.state_dict().items():
            if v.dtype.is_floating_point:
                v.mul_(d).add_((1 - d) * msd[k].detach())


# ─────────────────────────────────────────────────────────────────────────────
# Checkpoint helpers
# ─────────────────────────────────────────────────────────────────────────────

def _save_ckpt(path, model, optimizer, scaler, epoch, best_f1, logger):
    # always save the unwrapped module so checkpoints are DDP-agnostic
    raw = model.module if isinstance(model, DDP) else model
    torch.save({
        "epoch":     epoch,
        "model":     raw.state_dict(),
        "optimizer": optimizer.state_dict(),
        "scaler":    scaler.state_dict(),
        "best_f1":   best_f1,
    }, path)
    logger.info(f"  ✓ checkpoint → {path}")


def _load_ckpt(path, model, optimizer, scaler, device, logger):
    logger.info(f"Resuming from {path}")
    ckpt = torch.load(path, map_location=device)
    raw  = model.module if isinstance(model, DDP) else model
    raw.load_state_dict(ckpt["model"])
    if optimizer and "optimizer" in ckpt:
        optimizer.load_state_dict(ckpt["optimizer"])
    if scaler and "scaler" in ckpt:
        scaler.load_state_dict(ckpt["scaler"])
    return ckpt.get("epoch", 0), ckpt.get("best_f1", 0.0)


# ─────────────────────────────────────────────────────────────────────────────
# DataLoader builder (DDP-aware)
# ─────────────────────────────────────────────────────────────────────────────

def _build_loader(dc, mc, split: str, augment: bool,
                  rank: int = 0, world_size: int = 1):
    """
    Build a DataLoader for one split.

    In DDP mode a DistributedSampler is injected.  When weighted sampling is
    also requested (poly_weights), the DistributedSampler wraps the dataset
    after weights have been computed — the loader uses the DistributedSampler
    for epoch-level shuffling and the WeightedRandomSampler logic is replicated
    inside build_dataloader via the sampler= argument.
    """
    # ── resolve polygon datasets ──────────────────────────────────────────────
    if dc.poly_datasets:
        poly_ds = []
        for entry in dc.poly_datasets:
            if isinstance(entry, (list, tuple)) and len(entry) == 2:
                img_d, lbl_d = entry
            elif isinstance(entry, str) and ":" in entry:
                img_d, lbl_d = entry.split(":", 1)
            else:
                continue
            poly_ds.append((
                img_d.replace("{split}", split),
                lbl_d.replace("{split}", split),
            ))
        weights = list(dc.poly_weights) if dc.poly_weights else None
    else:
        poly_ds = [(
            os.path.join(dc.poly_dataset_root, f"images/{split}"),
            os.path.join(dc.poly_dataset_root, f"labels/{split}"),
        )]
        weights = None

    dist_img = dist_lbl = None
    if dc.dist_dataset_root:
        dist_img = os.path.join(dc.dist_dataset_root, f"images/{split}")
        dist_lbl = os.path.join(dc.dist_dataset_root, f"labels/{split}")

    return build_dataloader(
        poly_datasets = poly_ds,
        poly_weights  = weights,
        dist_img_dir  = dist_img,
        dist_lbl_dir  = dist_lbl,
        img_size      = dc.img_size,
        batch_size    = dc.batch_size,
        num_workers   = dc.num_workers,
        angle_step    = mc.angle_step,
        min_dist      = mc.min_distance,
        max_dist      = mc.max_distance,
        augment       = augment,
        hsv_h         = dc.hsv_h,
        hsv_s         = dc.hsv_s,
        hsv_v         = dc.hsv_v,
        flip_lr_prob  = dc.flip_lr_prob,
        mosaic_prob   = dc.mosaic_prob,
        # DDP — passed through to DataLoader
        ddp_rank       = rank,
        ddp_world_size = world_size,
    )


# ─────────────────────────────────────────────────────────────────────────────
# Validation  (runs on all ranks; metrics reduced to rank-0)
# ─────────────────────────────────────────────────────────────────────────────

@torch.no_grad()
def validate(
    model,
    val_loader,
    post_proc,
    cfg: Config,
    device,
    logger: Logger,
    vis: Visualiser,
    epoch: int,
    n_epochs: int = 0,
) -> Tuple[float, float, float, dict]:
    model.eval()
    mc = cfg.model
    dc = cfg.data
    tc = cfg.train

    metric = BBoxF1Metric(num_classes=mc.num_classes, iou_thres=0.5)

    vis_imgs_list:    List[torch.Tensor] = []
    vis_targets_list: List[torch.Tensor] = []
    vis_dets_list:    list               = []
    vis_collected = 0

    for imgs, targets in val_loader:
        imgs    = imgs.to(device)
        targets = targets.to(device)
        B       = imgs.shape[0]

        preds       = model(imgs)
        orig_shapes = [(dc.img_size, dc.img_size)] * B
        detections  = post_proc(preds, orig_shapes)

        if vis_collected < tc.vis_max_images and _is_main():
            take = min(B, tc.vis_max_images - vis_collected)
            bt   = targets[targets[:, 0] < take].cpu().clone()
            bt[:, 0] += vis_collected
            vis_imgs_list.append(imgs[:take].cpu())
            vis_targets_list.append(bt)
            vis_dets_list.extend(detections[:take])
            vis_collected += take

        for bi in range(B):
            mask = targets[:, 0] == bi
            gts  = []
            for row in targets[mask]:
                cls = int(row[1].item())
                cx  = row[2].item() * dc.img_size
                cy  = row[3].item() * dc.img_size
                w_  = row[4].item() * dc.img_size
                h_  = row[5].item() * dc.img_size
                gts.append((cls, cx - w_/2, cy - h_/2, cx + w_/2, cy + h_/2))
            metric.update(detections[bi], gts)

    result = metric.compute()
    micro  = result["micro"]

    if _is_main():
        logger.log_val(
            epoch=epoch, n_epochs=n_epochs,
            precision=micro["precision"],
            recall=micro["recall"],
            f1=micro["f1"],
            per_class=result,
            is_best=False,
        )

        if vis_imgs_list:
            all_imgs    = torch.cat(vis_imgs_list,    dim=0)
            all_targets = torch.cat(vis_targets_list, dim=0)
            vis.save_val_predictions(epoch, all_imgs, all_targets, vis_dets_list)

    model.train()
    return micro["f1"], micro["precision"], micro["recall"], result


# ─────────────────────────────────────────────────────────────────────────────
# Main training function
# ─────────────────────────────────────────────────────────────────────────────

def train(cfg: Config | None = None):
    # ── parse args / detect DDP environment ───────────────────────────────────
    # torchrun sets LOCAL_RANK automatically; fall back to single-GPU
    local_rank  = int(os.environ.get("LOCAL_RANK",  -1))
    global_rank = int(os.environ.get("RANK",        -1))
    world_size  = int(os.environ.get("WORLD_SIZE",   1))
    using_ddp   = (local_rank != -1)

    if using_ddp:
        _ddp_setup(local_rank, world_size)

    rank = _rank()
    main = _is_main()   # True only on rank-0

    if cfg is None:
        cfg, args = load_config(
            description="YOLOv8-Extended training",
            extra_args=[(\
                ["--no_amp"],
                dict(action="store_true",
                     help="Disable AMP (GradScaler + autocast)."),
            )],
        )
        resume_path = getattr(args, "resume", None)
        use_amp     = not args.no_amp
    else:
        resume_path = None
        use_amp     = True

    mc = cfg.model
    dc = cfg.data
    tc = cfg.train

    # ── device ────────────────────────────────────────────────────────────────
    if using_ddp:
        device = torch.device(f"cuda:{local_rank}")
    elif torch.cuda.is_available():
        device = torch.device(tc.device)
    else:
        device = torch.device("cpu")

    # ── experiment directory  (rank-0 creates, all ranks receive) ─────────────
    save_dir = _resolve_save_dir(tc.save_dir, resume_path)
    tc.save_dir = str(save_dir)

    # ── logger + visualiser  (rank-0 only) ────────────────────────────────────
    logger = Logger(save_dir=save_dir, use_tb=tc.tensorboard, rank=rank)
    logger.log_config(cfg)

    gpu_info = (f"{world_size} × GPU (DDP)"
                if using_ddp else str(device))
    logger.info(f"Experiment → {save_dir}")
    logger.info(f"Device     → {gpu_info}")

    class_names = dc.class_names if dc.class_names else None
    vis = Visualiser(
        save_dir       = save_dir,
        num_angles     = mc.num_angles,
        angle_step     = mc.angle_step,
        img_size       = dc.img_size,
        vis_max_images = tc.vis_max_images,
        conf_thresh    = tc.conf_thres,
        class_names    = class_names,
        logger         = logger,
    )

    # ── model ─────────────────────────────────────────────────────────────────
    model = YOLOv8Extended(
        model_size      = mc.model_size,
        num_classes     = mc.num_classes,
        num_angles      = mc.num_angles,
        num_dist_blocks = mc.num_dist_blocks,
        strides         = mc.strides,
    ).to(device)

    n_params = sum(p.numel() for p in model.parameters()) / 1e6
    logger.info(f"Model      → YOLOv8{mc.model_size}  |  {n_params:.1f}M parameters")

    # ── pretrained weights  (load before DDP wrap) ────────────────────────────
    if mc.pretrained and resume_path is None:
        logger.info("Loading pretrained YOLOv8 backbone + neck weights …")
        try:
            stats = model.load_pretrained_backbone(mc.model_size)
            logger.info(
                f"  Pretrained  matched={stats['matched']}  "
                f"skipped_shape={stats['skipped_shape']}  "
                f"skipped_name={stats['skipped_name']}  "
                f"total={stats['total_dst']}"
            )
            if stats["matched"] == 0:
                logger.warning(
                    "No weights matched — backbone/neck channel widths "
                    "may differ. Training from scratch."
                )
        except Exception as e:
            logger.warning(
                f"Could not load pretrained weights ({e}). "
                "Training from scratch. Pass --no_pretrained to suppress."
            )

    # ── DDP wrap ──────────────────────────────────────────────────────────────
    if using_ddp:
        # SyncBatchNorm improves accuracy when batch size per GPU is small
        model = torch.nn.SyncBatchNorm.convert_sync_batchnorm(model)
        model = DDP(model, device_ids=[local_rank], output_device=local_rank,
                    find_unused_parameters=False)
        logger.info(f"  DDP wrapped  (SyncBatchNorm enabled)")

    # ── loss ──────────────────────────────────────────────────────────────────
    criterion = YOLOv8ExtendedLoss(
        num_classes     = mc.num_classes,
        num_angles      = mc.num_angles,
        angle_step      = mc.angle_step,
        strides         = mc.strides,
        img_size        = dc.img_size,
        box_gain        = tc.box_gain,
        cls_gain        = tc.cls_gain,
        dfl_gain        = tc.dfl_gain,
        poly_gain       = tc.poly_gain,
        dist_gain       = tc.dist_gain,
        poly_dist_gain  = tc.poly_dist_gain,
        poly_conf_gain  = tc.poly_conf_gain,
        poly_angle_gain = tc.poly_angle_gain,
    ).to(device)

    # ── optimiser ─────────────────────────────────────────────────────────────
    # Build param groups from the underlying module (not the DDP wrapper)
    raw_model = model.module if isinstance(model, DDP) else model
    param_groups = [
        {"params": [p for n, p in raw_model.named_parameters()
                    if "bn" not in n and p.requires_grad],
         "weight_decay": tc.weight_decay},
        {"params": [p for n, p in raw_model.named_parameters()
                    if "bn" in n and p.requires_grad],
         "weight_decay": 0.0},
    ]
    # Scale LR linearly with world_size (linear scaling rule)
    scaled_lr0 = tc.lr0 * world_size
    scaled_lrf = tc.lrf * world_size
    optimizer  = optim.SGD(
        param_groups, lr=scaled_lr0, momentum=tc.momentum, nesterov=True
    )
    scaler = GradScaler(device.type, enabled=use_amp)

    if using_ddp and main:
        logger.info(f"  LR scaled  {tc.lr0:.4f} → {scaled_lr0:.4f} "
                    f"(× world_size={world_size})")

    # ── EMA  (rank-0 only) ────────────────────────────────────────────────────
    ema = ModelEMA(model) if main else None

    # ── data ──────────────────────────────────────────────────────────────────
    # Each rank gets its own shard via DistributedSampler
    train_loader = _build_loader(dc, mc, "train", augment=True,
                                 rank=rank, world_size=world_size)
    val_loader   = _build_loader(dc, mc, "val",   augment=False,
                                 rank=rank, world_size=world_size)

    n_poly_ds = len(dc.poly_datasets) if dc.poly_datasets else 1
    dist_info = ("+ dist dataset" if dc.dist_dataset_root else "no dist dataset")
    logger.info(
        f"Data       → {n_poly_ds} polygon dataset(s)  {dist_info}  "
        f"| train={len(train_loader)} batches/rank  "
        f"val={len(val_loader)} batches/rank"
    )

    # ── post-processor ────────────────────────────────────────────────────────
    post_proc = PostProcessor(
        num_classes     = mc.num_classes,
        num_angles      = mc.num_angles,
        strides         = mc.strides,
        img_size        = dc.img_size,
        conf_thres      = tc.conf_thres,
        iou_thres       = tc.iou_thres,
        poly_conf_thres = tc.conf_thres,
        min_distance    = mc.min_distance,
        max_distance    = mc.max_distance,
    )

    # ── resume ────────────────────────────────────────────────────────────────
    start_epoch = 0
    best_f1     = 0.0
    last_ckpt   = save_dir / "last.pt"
    if resume_path and Path(resume_path).exists():
        start_epoch, best_f1 = _load_ckpt(
            resume_path, model, optimizer, scaler, device, logger
        )
        start_epoch += 1
    elif last_ckpt.exists():
        start_epoch, best_f1 = _load_ckpt(
            str(last_ckpt), model, optimizer, scaler, device, logger
        )
        start_epoch += 1

    # ── training loop ─────────────────────────────────────────────────────────
    model.train()
    n_steps  = len(train_loader)
    n_epochs = tc.epochs

    for epoch in range(start_epoch, n_epochs):
        # DistributedSampler must be told the epoch to get different shuffles
        if using_ddp and hasattr(train_loader, "sampler"):
            sampler = train_loader.sampler
            if isinstance(sampler, DistributedSampler):
                sampler.set_epoch(epoch)

        lr = _cosine_lr(
            optimizer, epoch, n_epochs, tc.warmup_epochs,
            scaled_lr0, scaled_lrf,
        )

        epoch_loss:       float = 0.0
        epoch_loss_dict:  dict  = {}
        epoch_instances:  int   = 0
        t0 = time.time()

        vis_batch_imgs    = None
        vis_batch_targets = None

        if main:
            logger._print_epoch_header(epoch, n_epochs, n_steps, dc.img_size)

        for step, (imgs, targets) in enumerate(train_loader):
            imgs    = imgs.to(device, non_blocking=True)
            targets = targets.to(device, non_blocking=True)

            n_instances      = targets.shape[0]
            epoch_instances += n_instances

            if step == 0 and vis_batch_imgs is None and main:
                vis_batch_imgs    = imgs.detach().cpu()
                vis_batch_targets = targets.detach().cpu()

            with autocast(device.type, enabled=use_amp):
                preds           = model(imgs)
                loss, loss_dict = criterion(preds, targets)

            optimizer.zero_grad(set_to_none=True)
            scaler.scale(loss).backward()
            scaler.unscale_(optimizer)

            grad_norm = torch.nn.utils.clip_grad_norm_(
                model.parameters(), max_norm=10.0
            ).item()

            scaler.step(optimizer)
            scaler.update()

            if ema is not None:
                ema.update(model)

            # Reduce loss across ranks for accurate logging
            loss_val = _reduce_mean(loss.detach()).item()

            epoch_loss += loss_val
            for k, v in loss_dict.items():
                epoch_loss_dict[k] = epoch_loss_dict.get(k, 0.0) + v

            global_step = epoch * n_steps + step

            if main:
                logger.log_step(
                    epoch=epoch,   n_epochs=n_epochs,
                    step=step,     n_steps=n_steps,
                    loss=loss_val, loss_dict=loss_dict, lr=lr,
                    n_instances=n_instances, img_size=dc.img_size,
                )
                if step % tc.log_interval == 0:
                    logger.log_grad_norm(grad_norm, global_step)

        # ── epoch summary ─────────────────────────────────────────────────────
        avg_loss = epoch_loss / max(n_steps, 1)
        avg_dict = {k: v / max(n_steps, 1) for k, v in epoch_loss_dict.items()}
        elapsed  = time.time() - t0

        if main:
            logger.log_epoch(
                epoch=epoch, n_epochs=n_epochs,
                loss=avg_loss, loss_dict=avg_dict,
                lr=lr, elapsed=elapsed,
                n_instances=epoch_instances // max(n_steps, 1),
                img_size=dc.img_size,
            )

            if (epoch % tc.vis_interval == 0) and vis_batch_imgs is not None:
                vis.save_train_batch(epoch, vis_batch_imgs, vis_batch_targets)

            vis.update_loss_history(epoch, avg_loss, avg_dict)

        # ── validation ────────────────────────────────────────────────────────
        if (epoch + 1) % tc.val_interval == 0 or epoch == n_epochs - 1:
            # Use EMA model on rank-0, raw model on other ranks
            val_model = (ema.ema if ema is not None else
                         (model.module if isinstance(model, DDP) else model))

            f1, prec, rec, val_result = validate(
                val_model, val_loader, post_proc, cfg, device,
                logger, vis, epoch, n_epochs=n_epochs,
            )

            if main:
                vis.update_loss_history(
                    epoch, avg_loss, avg_dict,
                    val_f1=f1, val_prec=prec, val_rec=rec,
                )

                is_best = f1 > best_f1
                if is_best:
                    best_f1 = f1
                    logger.log_val(
                        epoch=epoch, n_epochs=n_epochs,
                        precision=prec, recall=rec, f1=f1,
                        per_class=val_result, is_best=True,
                    )
                    _save_ckpt(str(save_dir / "best.pt"),
                               model, optimizer, scaler, epoch, best_f1, logger)

                _save_ckpt(str(save_dir / "last.pt"),
                           model, optimizer, scaler, epoch, best_f1, logger)

        if main and epoch % tc.vis_interval == 0:
            vis.save_loss_curves(epoch)

        _barrier()   # keep all ranks in sync at epoch boundary

    if main:
        logger.info(f"\nBest F1 = {best_f1:.4f}  |  saved to {save_dir}")
        logger.close()

    if using_ddp:
        _ddp_teardown()


if __name__ == "__main__":
    train()
